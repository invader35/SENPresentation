///////////////////////////////////////
// Workfile    : TemplateShift.h
// Author      : Matthias Schett
// Date        : 19-05-2013
// Description : Shift function template
// Remarks     : -
// Revision    : 0
///////////////////////////////////////

#include "TemplateShift.h"
#include <iterator>


template <typename TItor, typename TValue>
void Shift(TItor begin, TItor end, size_t count, TValue val){

    
}